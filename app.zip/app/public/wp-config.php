<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '-@1j}(|<fu.G}z$ W%%cd]0cXL_mFd_B-`~m>PvJT^,jj@Y(DY5%3K|{3|ZQnO(G' );
define( 'SECURE_AUTH_KEY',   'AXR_^Xi_TG4JoiT6gCLu{p34Nr}x0V}{03.&$&rb>1|88psPn#c_-]Y!Ig)nRaVU' );
define( 'LOGGED_IN_KEY',     'DB@~fQ-P.I}LpHwF&a@71ZM8T:DG>%n1T]gR/_ohm$]tk[ECZRUV8Oh7a8I-A0jd' );
define( 'NONCE_KEY',         '|-fFpu_p`Vly2es76I71@(Qu{u*R*10M.%hu&qdw<+o*mn14=9am{={oXNqAm[z;' );
define( 'AUTH_SALT',         '-FY%h.P;:%ePUMQ)X/MHsf)I=@Gi9-VIW&R6v^2N<@*KJ3/;Y[E~.Y_}4ItJm I|' );
define( 'SECURE_AUTH_SALT',  'Yqk-,y >DWu6o{hSip_1$&)+32t`=2],hnl4[_,Mlak2FTO^fv|NMZoNueTD0)*3' );
define( 'LOGGED_IN_SALT',    'H#XxR+PhEKm<  ;/=N(.qgarCcT_+B@/e:,(ZOfT6yi+%P$t`wi{%FC-Fx%[<%S2' );
define( 'NONCE_SALT',        '=4t%~jJ^@@YJNxvnL}u7( =-n,oK$]1C[<{p:{*phf~[;=@tx8X~AsSQ3}g#YmEL' );
define( 'WP_CACHE_KEY_SALT', '@XYm*x25|$Q=ru]w|VKgO_K7xJ!qf|% wxG!|t5_v:AP&VPx[s.yrQV(SfcHkJG[' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
